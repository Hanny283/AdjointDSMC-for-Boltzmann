"""
Forward pass wrapper for adjoint DSMC simulation.

Runs the Nanbu-Babovsky DSMC simulation for M time steps, recording every
collision and boundary-reflection event in a structured history object.
The history object exposes a ``backward_pass`` method that walks the trace
in reverse to produce the velocity adjoints β and position adjoints α.

Data model
----------
At each step k the simulation does two sub-steps in order:

    1. Collision sub-step  (one Nanbu-Babovsky pair per collision record)
    2. Free-flight + boundary sub-step  (per particle)

Records mirror this order; the backward pass reverses it.

Classes
-------
CollisionRecord
    Stores indices, pre/post velocities, and the random unit vector ω for
    one collision pair at one step.

BoundaryRecord
    Stores the particle index, pre/post positions and velocities, the
    intersection angle θ_inter (or None if the particle stayed inside),
    and a boolean indicating whether a reflection occurred.

StepRecord
    Groups all CollisionRecord and BoundaryRecord objects for one step k,
    plus a snapshot of positions/velocities at the start and end of the step.

SimulationHistory
    Immutable container holding the full forward trace.  Provides
    ``backward_pass(terminal_beta_fn, terminal_alpha_fn)`` which returns
    β and α arrays of shape (M+1, N, 2).

ForwardSimulation
    Driver class.  ``run(positions, velocities, n_steps)`` executes the
    forward simulation and returns a SimulationHistory.

References
----------
Propositions 2.1 and 2.2 of the paper; Lemmas 2.2, 2.3, 2.9.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List, Optional

import numpy as np

from .boundary_geometry import (
    radius_r,
    normal_n,
    solve_theta_inter,
    compute_c_inter,
)
from .adjoint_jacobians import (
    dv_reflected_dv,
    compute_N_ki,
    collision_jacobian_transpose,
    apply_proposition_22,
)


# ---------------------------------------------------------------------------
# Helper: check whether a point is inside the star-shaped domain
# ---------------------------------------------------------------------------

def _is_inside(x: np.ndarray, C) -> bool:
    """Return True if point x lies strictly inside the Fourier boundary."""
    r_x = np.linalg.norm(x)
    if r_x == 0.0:
        return True
    theta = np.arctan2(x[1], x[0]) / (2.0 * np.pi) % 1.0
    return r_x < radius_r(theta, C)


# ---------------------------------------------------------------------------
# Helper: specular reflection
# ---------------------------------------------------------------------------

def _reflect(x_prime: np.ndarray, v_prime: np.ndarray, theta_inter: float, C):
    """
    Apply the specular reflection map at the boundary.

    Returns
    -------
    x_tilde : ndarray, shape (2,)
    v_tilde : ndarray, shape (2,)
    """
    n = normal_n(theta_inter, C)
    c = compute_c_inter(theta_inter, C)

    # ṽ = v' − 2⟨n, v'⟩ n
    v_tilde = v_prime - 2.0 * np.dot(n, v_prime) * n

    # x̃ = x' − 2(⟨n, x'⟩ − c) n
    x_tilde = x_prime - 2.0 * (np.dot(n, x_prime) - c) * n

    return x_tilde, v_tilde


# ---------------------------------------------------------------------------
# Record dataclasses
# ---------------------------------------------------------------------------

@dataclass
class CollisionRecord:
    """
    One Nanbu-Babovsky collision event.

    Attributes
    ----------
    idx_i, idx_i1 : int
        Indices of the two colliding particles (i and i').
    v_i, v_i1 : ndarray, shape (2,)
        Pre-collision velocities.
    v_prime_i, v_prime_i1 : ndarray, shape (2,)
        Post-collision velocities.
    omega : ndarray, shape (2,)
        Random unit vector ω drawn during the collision.
    """
    idx_i:      int
    idx_i1:     int
    v_i:        np.ndarray
    v_i1:       np.ndarray
    v_prime_i:  np.ndarray
    v_prime_i1: np.ndarray
    omega:      np.ndarray


@dataclass
class BoundaryRecord:
    """
    One free-flight + (optional) boundary-reflection event for a particle.

    Attributes
    ----------
    idx : int
        Particle index.
    x_k : ndarray, shape (2,)
        Position at the start of the free-flight (before moving).
    v_prime : ndarray, shape (2,)
        Velocity used for free-flight (post-collision velocity).
    x_prime : ndarray, shape (2,)
        Position after free-flight (x_k + dt * v_prime), before reflection.
    in_domain : bool
        True if x_prime is inside the domain (no reflection needed).
    theta_inter : float or None
        Intersection angle θ_inter; None when in_domain is True.
    x_tilde : ndarray, shape (2,)
        Final position (= x_prime if in_domain, reflected otherwise).
    v_tilde : ndarray, shape (2,)
        Final velocity (= v_prime if in_domain, reflected otherwise).
    """
    idx:         int
    x_k:         np.ndarray
    v_prime:     np.ndarray
    x_prime:     np.ndarray
    in_domain:   bool
    theta_inter: Optional[float]
    x_tilde:     np.ndarray
    v_tilde:     np.ndarray


@dataclass
class StepRecord:
    """
    All events that occurred during step k.

    Attributes
    ----------
    k : int
        Time step index (0-based).
    positions_start : ndarray, shape (N, 2)
        Particle positions at the beginning of step k.
    velocities_start : ndarray, shape (N, 2)
        Particle velocities at the beginning of step k.
    collisions : list of CollisionRecord
        Collision events (may be empty if n_coll_pairs == 0).
    boundary : list of BoundaryRecord
        One record per particle for the free-flight / reflection sub-step.
    positions_end : ndarray, shape (N, 2)
        Particle positions at the end of step k.
    velocities_end : ndarray, shape (N, 2)
        Particle velocities at the end of step k.
    """
    k:                int
    positions_start:  np.ndarray
    velocities_start: np.ndarray
    collisions:       List[CollisionRecord] = field(default_factory=list)
    boundary:         List[BoundaryRecord]  = field(default_factory=list)
    positions_end:    np.ndarray = field(default_factory=lambda: np.empty((0, 2)))
    velocities_end:   np.ndarray = field(default_factory=lambda: np.empty((0, 2)))


# ---------------------------------------------------------------------------
# SimulationHistory
# ---------------------------------------------------------------------------

@dataclass
class SimulationHistory:
    """
    Immutable record of a complete forward simulation.

    Attributes
    ----------
    C : ndarray, shape (2N+1,)
        Fourier boundary coefficients used during the run.
    dt : float
        Time step size.
    steps : list of StepRecord
        One entry per time step k = 0, …, M-1.

    Properties
    ----------
    n_steps : int         (= M)
    n_particles : int     (= N)
    final_positions : ndarray, shape (N, 2)
    final_velocities : ndarray, shape (N, 2)

    Methods
    -------
    backward_pass(terminal_beta_fn, terminal_alpha_fn) → (betas, alphas)
        Walk the trace backwards to compute adjoints.
    """
    C:     np.ndarray
    dt:    float
    steps: List[StepRecord]

    # ------------------------------------------------------------------
    # Convenience properties
    # ------------------------------------------------------------------

    @property
    def n_steps(self) -> int:
        return len(self.steps)

    @property
    def n_particles(self) -> int:
        if not self.steps:
            return 0
        return self.steps[0].positions_start.shape[0]

    @property
    def final_positions(self) -> np.ndarray:
        if not self.steps:
            raise ValueError("No steps recorded.")
        return self.steps[-1].positions_end

    @property
    def final_velocities(self) -> np.ndarray:
        if not self.steps:
            raise ValueError("No steps recorded.")
        return self.steps[-1].velocities_end

    # ------------------------------------------------------------------
    # Backward pass
    # ------------------------------------------------------------------

    def backward_pass(
        self,
        terminal_beta_fn:  Callable[[np.ndarray, np.ndarray], np.ndarray],
        terminal_alpha_fn: Callable[[np.ndarray, np.ndarray], np.ndarray],
    ):
        """
        Compute velocity adjoints β and position adjoints α by walking
        the recorded forward trace in reverse.

        Parameters
        ----------
        terminal_beta_fn : callable (velocities, positions) → ndarray (N, 2)
            Terminal condition β_M = ∂L/∂v_M per particle.
        terminal_alpha_fn : callable (velocities, positions) → ndarray (N, 2)
            Terminal condition α_M = ∂L/∂x_M per particle.

        Returns
        -------
        betas : ndarray, shape (M+1, N, 2)
            β_{k, i, :} for k = 0, …, M.
        alphas : ndarray, shape (M+1, N, 2)
            α_{k, i, :} for k = 0, …, M.

        Notes
        -----
        The backward recurrence at step k (running from M-1 down to 0):

        α backward (Proposition 2.2, per particle, no coupling):
            α_{k,i} = G_{k,i}^T α_{k+1,i}   if boundary hit at step k
            α_{k,i} = α_{k+1,i}              otherwise

        β backward (Proposition 2.1, two sub-steps reversed):

          Sub-step A — boundary / free-flight (applied before collision
          in the backward direction):
            For each particle i:
              if in_domain:   rhs_i = β_{k+1,i} + dt * α_{k+1,i}
              if boundary hit: rhs_i = M_{k,i}^T β_{k+1,i}
                                       + N_{k,i}^T α_{k+1,i}

          Sub-step B — collision Jacobian^T (couples pair (i, i')):
            For each CollisionRecord with pre-collision v_i, v_i1, ω:
              J_T = J_coll(v_i, v_i1, ω)^T
              [β_{k,i}; β_{k,i1}] = J_T * [rhs_i; rhs_i1]
            Non-collided particles: β_{k,i} = rhs_i
        """
        M = self.n_steps
        N = self.n_particles
        C = self.C
        dt = self.dt

        # Allocate output arrays
        betas  = np.zeros((M + 1, N, 2))
        alphas = np.zeros((M + 1, N, 2))

        # Terminal conditions at step M
        x_M = self.final_positions
        v_M = self.final_velocities
        betas[M]  = np.asarray(terminal_beta_fn(v_M, x_M),  dtype=float)
        alphas[M] = np.asarray(terminal_alpha_fn(v_M, x_M), dtype=float)

        # Walk backwards k = M-1, …, 0
        for k in reversed(range(M)):
            step = self.steps[k]
            beta_k1  = betas[k + 1]   # shape (N, 2)
            alpha_k1 = alphas[k + 1]  # shape (N, 2)

            # Build a lookup from particle index to its BoundaryRecord
            bdry_by_idx: dict[int, BoundaryRecord] = {
                rec.idx: rec for rec in step.boundary
            }

            # ----------------------------------------------------------
            # α backward step (Proposition 2.2): per-particle, independent
            # ----------------------------------------------------------
            alpha_k = np.empty((N, 2))
            for i in range(N):
                rec = bdry_by_idx.get(i)
                if rec is None:
                    alpha_k[i] = alpha_k1[i]
                else:
                    alpha_k[i] = apply_proposition_22(
                        alpha_k1=alpha_k1[i],
                        theta_inter=rec.theta_inter,
                        x_prime=rec.x_prime,
                        v_k=rec.v_prime,
                        C=C,
                        in_domain=rec.in_domain,
                    )
            alphas[k] = alpha_k

            # ----------------------------------------------------------
            # β backward step — Sub-step A:
            # Apply boundary / free-flight Jacobians to get rhs per particle
            # ----------------------------------------------------------
            rhs = np.empty((N, 2))
            for i in range(N):
                rec = bdry_by_idx.get(i)
                if rec is None or rec.in_domain:
                    # No boundary hit: identity velocity map, free-flight α coupling
                    rhs[i] = beta_k1[i] + dt * alpha_k1[i]
                else:
                    # Boundary hit: M^T β + N^T α
                    Mmat = dv_reflected_dv(rec.theta_inter, rec.x_k,
                                          rec.v_prime, C)
                    Nmat = compute_N_ki(rec.theta_inter, rec.x_prime,
                                       rec.x_k, rec.v_prime, C, dt)
                    rhs[i] = Mmat.T @ beta_k1[i] + Nmat.T @ alpha_k1[i]

            # ----------------------------------------------------------
            # β backward step — Sub-step B:
            # Propagate rhs through J_coll^T for each collision pair.
            # rhs already incorporates the boundary / free-flight Jacobians;
            # we only need to apply J_coll^T (v_i, v_i1, ω from forward).
            # ----------------------------------------------------------
            beta_k = rhs.copy()  # non-collided particles keep their rhs

            for crec in step.collisions:
                i  = crec.idx_i
                i1 = crec.idx_i1
                J_T = collision_jacobian_transpose(crec.v_i, crec.v_i1, crec.omega)
                stacked = J_T @ np.concatenate([rhs[i], rhs[i1]])   # shape (4,)
                beta_k[i]  = stacked[:2]
                beta_k[i1] = stacked[2:]

            betas[k] = beta_k

        return betas, alphas


# ---------------------------------------------------------------------------
# ForwardSimulation
# ---------------------------------------------------------------------------

class ForwardSimulation:
    """
    Driver for the forward Nanbu-Babovsky DSMC simulation.

    Parameters
    ----------
    C : array-like, shape (2N+1,)
        Fourier boundary coefficients.
    dt : float
        Time step size.
    n_coll_pairs : int or None
        Fixed number of collision pairs per step.  If None, defaults to
        N // 2 (maximum possible for N particles).
    seed : int or None
        Seed for the internal NumPy random generator.

    Methods
    -------
    run(positions, velocities, n_steps) → SimulationHistory
    """

    def __init__(
        self,
        C,
        dt: float,
        n_coll_pairs: Optional[int] = None,
        seed: Optional[int] = None,
    ):
        self.C  = np.asarray(C, dtype=float)
        self.dt = float(dt)
        self._n_coll_pairs = n_coll_pairs
        self._rng = np.random.default_rng(seed)

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def run(
        self,
        positions:  np.ndarray,
        velocities: np.ndarray,
        n_steps:    int,
    ) -> SimulationHistory:
        """
        Run the simulation for ``n_steps`` steps.

        Parameters
        ----------
        positions : ndarray, shape (N, 2)
        velocities : ndarray, shape (N, 2)
        n_steps : int

        Returns
        -------
        SimulationHistory
        """
        x = np.asarray(positions,  dtype=float).copy()
        v = np.asarray(velocities, dtype=float).copy()
        N = x.shape[0]
        n_coll = self._n_coll_pairs if self._n_coll_pairs is not None else N // 2

        steps = []

        for k in range(n_steps):
            x_start = x.copy()
            v_start = v.copy()

            # -- Collision sub-step ------------------------------------
            collision_records = self._collision_step(v, n_coll)

            # -- Free-flight + boundary sub-step ----------------------
            boundary_records = self._boundary_step(x, v)

            steps.append(StepRecord(
                k=k,
                positions_start=x_start,
                velocities_start=v_start,
                collisions=collision_records,
                boundary=boundary_records,
                positions_end=x.copy(),
                velocities_end=v.copy(),
            ))

        return SimulationHistory(C=self.C.copy(), dt=self.dt, steps=steps)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _collision_step(
        self, v: np.ndarray, n_coll: int
    ) -> List[CollisionRecord]:
        """
        Perform ``n_coll`` Nanbu-Babovsky collision pairs, mutate ``v``
        in-place, and return the list of CollisionRecord objects.
        """
        N = v.shape[0]
        if n_coll == 0 or N < 2:
            return []

        # Sample 2*n_coll distinct indices for the collision pairs
        indices = self._rng.choice(N, size=2 * n_coll, replace=False)
        i_indices  = indices[:n_coll]
        i1_indices = indices[n_coll:]

        records = []
        for idx_i, idx_i1 in zip(i_indices, i1_indices):
            v_i  = v[idx_i].copy()
            v_i1 = v[idx_i1].copy()

            # Nanbu-Babovsky rule
            v_cm      = 0.5 * (v_i + v_i1)
            v_rel_mag = np.linalg.norm(v_i - v_i1)

            angle = self._rng.uniform(0.0, 2.0 * np.pi)
            omega = np.array([np.cos(angle), np.sin(angle)])

            v_prime_i  = v_cm + 0.5 * v_rel_mag * omega
            v_prime_i1 = v_cm - 0.5 * v_rel_mag * omega

            v[idx_i]  = v_prime_i
            v[idx_i1] = v_prime_i1

            records.append(CollisionRecord(
                idx_i=int(idx_i),
                idx_i1=int(idx_i1),
                v_i=v_i,
                v_i1=v_i1,
                v_prime_i=v_prime_i.copy(),
                v_prime_i1=v_prime_i1.copy(),
                omega=omega.copy(),
            ))

        return records

    def _boundary_step(
        self, x: np.ndarray, v: np.ndarray
    ) -> List[BoundaryRecord]:
        """
        Advance each particle by ``dt``, apply specular reflection if
        needed, mutate ``x`` and ``v`` in-place, and return BoundaryRecords.
        """
        C  = self.C
        dt = self.dt
        N  = x.shape[0]
        records = []

        for i in range(N):
            x_k     = x[i].copy()
            v_prime = v[i].copy()  # velocity is already post-collision
            x_prime = x_k + dt * v_prime

            if _is_inside(x_prime, C):
                # Particle stays inside — no reflection
                x[i] = x_prime
                records.append(BoundaryRecord(
                    idx=i,
                    x_k=x_k,
                    v_prime=v_prime,
                    x_prime=x_prime,
                    in_domain=True,
                    theta_inter=None,
                    x_tilde=x_prime,
                    v_tilde=v_prime,
                ))
            else:
                # Find boundary intersection and reflect
                theta_inter = solve_theta_inter(x_k, v_prime, C)

                if theta_inter is None:
                    # No intersection found: keep particle at x_k (do not let
                    # it escape; this is a rare numerical edge case).
                    x[i] = x_k
                    records.append(BoundaryRecord(
                        idx=i,
                        x_k=x_k,
                        v_prime=v_prime,
                        x_prime=x_prime,
                        in_domain=True,
                        theta_inter=None,
                        x_tilde=x_k,
                        v_tilde=v_prime,
                    ))
                else:
                    x_tilde, v_tilde = _reflect(x_prime, v_prime, theta_inter, C)

                    # Safety clamp: if the tangent-plane reflection still lands
                    # outside (nearly-tangential trajectories), pull the particle
                    # to just inside the boundary point.
                    if not _is_inside(x_tilde, C):
                        r_b = radius_r(theta_inter, C)
                        x_tilde = (r_b * 0.9999) * np.array([
                            np.cos(2 * np.pi * theta_inter),
                            np.sin(2 * np.pi * theta_inter),
                        ])

                    x[i] = x_tilde
                    v[i] = v_tilde
                    records.append(BoundaryRecord(
                        idx=i,
                        x_k=x_k,
                        v_prime=v_prime,
                        x_prime=x_prime,
                        in_domain=False,
                        theta_inter=theta_inter,
                        x_tilde=x_tilde,
                        v_tilde=v_tilde,
                    ))

        return records
